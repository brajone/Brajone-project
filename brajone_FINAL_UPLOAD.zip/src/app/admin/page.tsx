"use client";

import { useState } from "react";
import { Plus, Trash, Edit, LogOut, LayoutDashboard, Home, FolderKanban, Settings } from "lucide-react";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("properties");

  return (
    <div className="min-h-screen bg-black flex flex-col md:flex-row">
      {/* Sidebar */}
      <div className="w-full md:w-64 bg-luxury-charcoal border-r border-white/5 p-6 flex flex-col justify-between">
        <div className="space-y-12">
          <img src="/logo.jpg" alt="Brajone Admin" className="h-12 w-auto mx-auto" />
          
          <nav className="space-y-4">
            <button 
              onClick={() => setActiveTab("properties")}
              className={`flex items-center gap-3 w-full p-3 text-sm uppercase tracking-widest transition-colors ${activeTab === 'properties' ? 'text-gold bg-gold/5' : 'text-gray-400 hover:text-white'}`}
            >
              <Home size={18} /> Properties
            </button>
            <button 
              onClick={() => setActiveTab("projects")}
              className={`flex items-center gap-3 w-full p-3 text-sm uppercase tracking-widest transition-colors ${activeTab === 'projects' ? 'text-gold bg-gold/5' : 'text-gray-400 hover:text-white'}`}
            >
              <FolderKanban size={18} /> Projects
            </button>
            <button 
              className="flex items-center gap-3 w-full p-3 text-sm uppercase tracking-widest text-gray-400 hover:text-white"
            >
              <Settings size={18} /> Settings
            </button>
          </nav>
        </div>

        <button className="flex items-center gap-3 text-red-500 text-sm uppercase tracking-widest p-3 hover:bg-red-500/5">
          <LogOut size={18} /> Logout
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-grow p-10 overflow-y-auto">
        <div className="flex justify-between items-center mb-12">
          <h1 className="text-4xl font-serif font-bold">Properties <span className="text-gold">Management</span></h1>
          <button className="btn-gold flex items-center gap-2 px-6 py-3">
            <Plus size={18} /> Add Property
          </button>
        </div>

        <div className="bg-luxury-charcoal border border-white/10">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-white/5 text-[10px] uppercase tracking-[0.2em] text-gray-500">
                <th className="p-6">Property Name</th>
                <th className="p-6">Location</th>
                <th className="p-6">Price</th>
                <th className="p-6">Status</th>
                <th className="p-6 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {[1, 2, 3].map((item) => (
                <tr key={item} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                  <td className="p-6 font-medium">The Golden Sanctuary {item}</td>
                  <td className="p-6 text-gray-400">Raman Reti</td>
                  <td className="p-6">₹1.5 Cr</td>
                  <td className="p-6">
                    <span className="bg-green-500/20 text-green-500 px-2 py-1 text-[10px] uppercase tracking-widest rounded-full">Active</span>
                  </td>
                  <td className="p-6 text-right space-x-4">
                    <button className="text-blue-400 hover:text-blue-300"><Edit size={18} /></button>
                    <button className="text-red-400 hover:text-red-300"><Trash size={18} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

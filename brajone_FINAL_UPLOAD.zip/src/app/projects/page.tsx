import Link from "next/link";
import { ChevronRight, Building, MapPin } from "lucide-react";

const projects = [
  {
    id: "proj-1",
    name: "Vraj Royal Estate",
    location: "Near Iskcon Temple, Vrindavan",
    type: "Township",
    status: "Upcoming",
    image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=800",
    description: "A sprawling 50-acre township with international amenities."
  },
  {
    id: "proj-2",
    name: "Radha Rani Greens",
    location: "Near Temple, Barsana",
    type: "Boutique Villas",
    status: "Pre-Launch",
    image: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=800",
    description: "Exclusive luxury villas situated in the serene hills of Barsana."
  },
  {
    id: "proj-3",
    name: "Braj Residency",
    location: "Chatikara Road, Mathura",
    type: "Residential",
    status: "Pre-Launch",
    image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=800",
    description: "Modern luxury apartments with a direct view of Vrindavan."
  }
];

export default function ProjectsPage() {
  return (
    <div className="pt-32 pb-24 px-6 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <h1 className="text-5xl md:text-7xl font-serif font-bold mb-4">Iconic <span className="text-gold">Developments</span></h1>
          <p className="text-gray-400 uppercase tracking-widest text-sm">Shaping the skyline of the Holy City</p>
        </div>

        <div className="space-y-24">
          {projects.map((proj, i) => (
            <div key={proj.id} className={`flex flex-col ${i % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} gap-12 items-center`}>
              <div className="w-full lg:w-1/2 overflow-hidden border border-gold/20">
                <img src={proj.image} alt={proj.name} className="w-full h-[400px] object-cover hover:scale-105 transition-transform duration-700" />
              </div>
              <div className="w-full lg:w-1/2 space-y-6">
                <div className="flex items-center gap-4">
                  <span className="text-gold text-xs uppercase tracking-widest font-bold px-3 py-1 border border-gold/30">{proj.status}</span>
                  <span className="text-gray-500 text-xs uppercase tracking-[0.2em] flex items-center gap-2"><Building size={14}/> {proj.type}</span>
                </div>
                <h2 className="text-4xl font-serif font-bold">{proj.name}</h2>
                <div className="flex items-center gap-2 text-gray-400">
                  <MapPin size={16} className="text-gold" />
                  <span>{proj.location}</span>
                </div>
                <p className="text-gray-400 leading-relaxed font-light text-lg">
                  {proj.description}
                </p>
                <div className="pt-4">
                  <button className="btn-gold px-8 py-3 text-xs">Request Brochure</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

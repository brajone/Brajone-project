import Hero from "@/components/sections/Hero";
import PropertyCard from "@/components/ui/PropertyCard";
import { Property } from "@/types/property";
import Link from "next/link";

const featuredProperties: Property[] = [
  {
    id: "1",
    title: "The Golden Sanctuary",
    price: 15000000,
    location: "Raman Reti, Vrindavan",
    beds: 3,
    baths: 3,
    sqft: 2400,
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800",
    category: "Apartment",
    status: "Ready to Move",
  },
  {
    id: "2",
    title: "Vraj Heights",
    price: 8500000,
    location: "Chaitanya Vihar, Vrindavan",
    beds: 2,
    baths: 2,
    sqft: 1200,
    image: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=800",
    category: "Apartment",
    status: "Under Construction",
  },
  {
    id: "3",
    title: "Radha Rani Villas",
    price: 45000000,
    location: "Sunrakh Road, Vrindavan",
    beds: 5,
    baths: 6,
    sqft: 5000,
    image: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=800",
    category: "Villa",
    status: "Ready to Move",
  },
];

export default function Home() {
  return (
    <div className="bg-black">
      <Hero />
      
      {/* Featured Properties */}
      <section className="py-24 px-6 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
          <div className="space-y-4">
            <h2 className="text-gold uppercase tracking-[0.3em] text-sm">Real Estate in Braj Region</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold">Vrindavan & Mathura Collection</h3>
          </div>
          <Link href="/properties" className="btn-outline-gold text-xs px-8 py-3">
            Explore All
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredProperties.map((p) => (
            <PropertyCard key={p.id} property={p} />
          ))}
        </div>
      </section>

      {/* Localities Section for SEO */}
      <section className="py-24 bg-black border-y border-white/5">
        <div className="max-w-7xl mx-auto px-6">
           <h2 className="text-gold text-center uppercase tracking-[0.4em] text-xs mb-12">Premier Locations</h2>
           <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {['Vrindavan', 'Mathura', 'Govardhan', 'Barsana'].map(loc => (
                <div key={loc} className="text-center group cursor-pointer">
                   <div className="text-3xl md:text-5xl font-serif font-bold text-white/20 group-hover:text-gold transition-colors duration-500 mb-2">{loc}</div>
                   <p className="text-[10px] text-gray-500 uppercase tracking-widest">Luxury Developments</p>
                </div>
              ))}
           </div>
        </div>
      </section>

      {/* Philosophy Section */}
      <section className="py-24 bg-luxury-charcoal border-y border-gold/10 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div className="relative">
            <div className="absolute -top-10 -left-10 w-64 h-64 bg-gold/10 rounded-full blur-3xl" />
            <img 
              src="https://images.unsplash.com/photo-1544161515-4ab6ce6db874?auto=format&fit=crop&q=80&w=800" 
              alt="Spirituality" 
              className="relative z-10 w-full grayscale hover:grayscale-0 transition-all duration-700"
            />
          </div>
          <div className="space-y-8">
            <h2 className="text-gold uppercase tracking-[0.3em] text-sm">Our Philosophy</h2>
            <h3 className="text-4xl md:text-6xl font-serif font-bold leading-tight">
              Where Divinity <br /> Meets <span className="text-gold italic">Luxury</span>
            </h3>
            <p className="text-gray-400 leading-relaxed text-lg font-light">
              Brajone was founded on the principle that the holy land of Vrindavan deserves architecture as divine as its atmosphere. We blend global luxury standards with the timeless spirituality of Braj.
            </p>
            <div className="grid grid-cols-2 gap-8 pt-8">
              <div>
                <h4 className="text-gold text-3xl font-serif mb-2">10+</h4>
                <p className="text-xs uppercase tracking-widest text-gray-500">Years Excellence</p>
              </div>
              <div>
                <h4 className="text-gold text-3xl font-serif mb-2">500+</h4>
                <p className="text-xs uppercase tracking-widest text-gray-500">Happy Families</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="relative py-32 px-6 overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1200')] bg-fixed bg-cover bg-center opacity-20" />
        <div className="relative z-10 max-w-4xl mx-auto text-center space-y-10">
          <h2 className="text-4xl md:text-6xl font-serif font-bold">Ready to find your <br /> <span className="text-gold">Spiritual Home?</span></h2>
          <p className="text-gray-300 text-lg font-light">Consult with our expert advisors for a personalized site visit.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-6">
            <button className="btn-gold px-12 py-5">Request Callback</button>
            <button className="btn-outline-gold px-12 py-5">Download Brochure</button>
          </div>
        </div>
      </section>
    </div>
  );
}

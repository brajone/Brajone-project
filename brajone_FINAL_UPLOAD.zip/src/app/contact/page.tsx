import { Phone, Mail, MapPin, Send } from "lucide-react";

export default function ContactPage() {
  return (
    <div className="pt-32 pb-24 px-6 bg-black">
      <div className="max-w-7xl mx-auto">
        <div className="text-center space-y-4 mb-20">
          <h1 className="text-5xl md:text-7xl font-serif font-bold">Connect <span className="text-gold">With Us</span></h1>
          <p className="text-gray-400 max-w-2xl mx-auto uppercase tracking-widest text-sm">Experience the Brajone Hospitality</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Contact Form */}
          <div className="bg-luxury-charcoal border border-white/10 p-10 space-y-8">
            <h2 className="text-3xl font-serif font-bold">Inquiry Form</h2>
            <form className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-[0.2em] text-gray-500 font-bold">Full Name</label>
                  <input className="w-full bg-black border border-white/10 p-3 focus:border-gold outline-none transition-colors" placeholder="John Doe" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs uppercase tracking-[0.2em] text-gray-500 font-bold">Phone Number</label>
                  <input className="w-full bg-black border border-white/10 p-3 focus:border-gold outline-none transition-colors" placeholder="+91 00000 00000" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-[0.2em] text-gray-500 font-bold">Interest In</label>
                <select className="w-full bg-black border border-white/10 p-3 focus:border-gold outline-none transition-colors">
                  <option>Luxury Apartment</option>
                  <option>Boutique Villa</option>
                  <option>Investment Plot</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-[0.2em] text-gray-500 font-bold">Message</label>
                <textarea rows={4} className="w-full bg-black border border-white/10 p-3 focus:border-gold outline-none transition-colors" placeholder="How can we assist you?" />
              </div>
              <button className="btn-gold w-full py-4 flex items-center justify-center gap-2">
                <Send size={18} /> Send Inquiry
              </button>
            </form>
          </div>

          {/* Contact Details */}
          <div className="space-y-12">
            <div className="space-y-6">
              <h2 className="text-3xl font-serif font-bold">Vrindavan Office</h2>
              <p className="text-gray-400 font-light">Visit our experience center to witness the fusion of divinity and design.</p>
            </div>

            <div className="space-y-8">
              <div className="flex items-start gap-6">
                <div className="bg-gold/10 p-4 rounded-full text-gold">
                  <MapPin size={24} />
                </div>
                <div>
                  <h4 className="font-serif text-xl mb-1">Location</h4>
                  <p className="text-gray-400 text-sm">Brajone House, Sunrakh Road, Vrindavan, UP</p>
                </div>
              </div>

              <div className="flex items-start gap-6">
                <div className="bg-gold/10 p-4 rounded-full text-gold">
                  <Phone size={24} />
                </div>
                <div>
                  <h4 className="font-serif text-xl mb-1">Direct Lines</h4>
                  <p className="text-gray-400 text-sm">+91 7900780022 / 23</p>
                </div>
              </div>

              <div className="flex items-start gap-6">
                <div className="bg-gold/10 p-4 rounded-full text-gold">
                  <Mail size={24} />
                </div>
                <div>
                  <h4 className="font-serif text-xl mb-1">Email</h4>
                  <p className="text-gray-400 text-sm">brajone.com@gmail.com</p>
                </div>
              </div>
            </div>

            {/* Google Map Mockup */}
            <div className="h-64 bg-white/5 border border-white/10 flex items-center justify-center grayscale">
              <span className="text-gray-500 uppercase tracking-widest text-xs">Google Maps Integration</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

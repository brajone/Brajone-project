export default function AboutPage() {
  return (
    <div className="pt-32 bg-black">
      {/* Hero Section */}
      <section className="px-6 max-w-7xl mx-auto mb-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <div className="space-y-8">
            <h1 className="text-6xl md:text-8xl font-serif font-bold leading-none">
              Legacy of <br /> <span className="text-gold">Divine Living</span>
            </h1>
            <p className="text-xl text-gray-400 font-light leading-relaxed">
              Brajone is more than a real estate firm; it's a commitment to preserving the sanctity of Vrindavan while introducing unparalleled luxury.
            </p>
          </div>
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1544161515-4ab6ce6db874?auto=format&fit=crop&q=80&w=800" 
              className="w-full h-[600px] object-cover border border-gold/30"
              alt="Brajone Legacy"
            />
            <div className="absolute -bottom-10 -right-10 bg-gold p-10 hidden md:block">
              <p className="text-black font-serif text-5xl font-bold">15+</p>
              <p className="text-black text-xs uppercase tracking-widest font-bold">Years of Heritage</p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-luxury-charcoal py-32 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-16">
          <div className="space-y-6">
            <div className="text-gold text-4xl font-serif">01</div>
            <h3 className="text-2xl font-serif font-bold uppercase tracking-widest">Purity</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              We respect the spiritual vibration of the land, ensuring every project is Vastu-compliant and environmentally conscious.
            </p>
          </div>
          <div className="space-y-6">
            <div className="text-gold text-4xl font-serif">02</div>
            <h3 className="text-2xl font-serif font-bold uppercase tracking-widest">Excellence</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              From Italian marble to smart home automation, we bring global standards to the holy city.
            </p>
          </div>
          <div className="space-y-6">
            <div className="text-gold text-4xl font-serif">03</div>
            <h3 className="text-2xl font-serif font-bold uppercase tracking-widest">Trust</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              Transparent transactions and on-time delivery are the cornerstones of the Brajone experience.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}

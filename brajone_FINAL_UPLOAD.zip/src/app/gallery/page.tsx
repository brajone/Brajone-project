export default function GalleryPage() {
  const images = [
    "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?auto=format&fit=crop&q=80&w=800"
  ];

  return (
    <div className="pt-32 pb-24 px-6 bg-black min-h-screen">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-serif font-bold mb-4">Visual <span className="text-gold">Heritage</span></h1>
          <p className="text-gray-400 uppercase tracking-widest text-sm">A glimpse into spiritual luxury</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {images.map((img, i) => (
            <div key={i} className="group relative aspect-square overflow-hidden border border-white/5 cursor-pointer">
              <img src={img} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt="Gallery" />
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="text-gold text-xs uppercase tracking-widest border border-gold/50 px-4 py-2">View Large</span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-20 text-center space-y-8">
          <h2 className="text-3xl font-serif font-bold">Drone <span className="text-gold">Footage</span></h2>
          <div className="aspect-video bg-luxury-charcoal border border-gold/20 flex items-center justify-center text-gray-500 font-serif italic text-xl">
             Video Gallery Player Integration
          </div>
        </div>
      </div>
    </div>
  );
}

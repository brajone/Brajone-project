"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate login
    if (email === "admin@brajone.com" && password === "admin123") {
      router.push("/admin");
    } else {
      alert("Invalid credentials. Try admin@brajone.com / admin123");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-black px-6">
      <div className="w-full max-w-md bg-luxury-charcoal border border-gold/20 p-10 space-y-8">
        <div className="text-center">
          <img src="/logo.jpg" alt="Brajone" className="h-24 mx-auto mb-6" />
          <h1 className="text-2xl font-serif font-bold text-gold">Admin Portal</h1>
          <p className="text-gray-400 text-sm mt-2">Brajone Executive Access Only</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div className="space-y-2">
            <label className="text-xs uppercase tracking-widest text-gray-400">Email Address</label>
            <input 
              type="email" 
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-black border border-white/10 px-4 py-3 text-white focus:border-gold outline-none transition-all"
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs uppercase tracking-widest text-gray-400">Password</label>
            <input 
              type="password" 
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-black border border-white/10 px-4 py-3 text-white focus:border-gold outline-none transition-all"
            />
          </div>

          <button type="submit" className="btn-gold w-full py-4 mt-4">
            Authorize Access
          </button>
        </form>
      </div>
    </div>
  );
}

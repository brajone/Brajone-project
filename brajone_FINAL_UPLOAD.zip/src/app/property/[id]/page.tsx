import { formatPrice } from "@/lib/utils";
import { Bed, Bath, Square, MapPin, CheckCircle, Calendar } from "lucide-react";
import EMICalculator from "@/components/ui/EMICalculator";

// Mock data fetching
const getProperty = (id: string) => ({
  id,
  title: "The Golden Sanctuary",
  price: 15000000,
  location: "Raman Reti, Vrindavan",
  beds: 3,
  baths: 3,
  sqft: 2400,
  images: [
    "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1200",
    "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=1200",
    "https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&q=80&w=1200"
  ],
  description: "Experience spiritual bliss in this luxury residence located in the heart of Raman Reti. This property features premium Italian marble flooring, a private meditation garden, and 24/7 power backup.",
  features: ["Private Garden", "Vastu Compliant", "Smart Home", "24/7 Security", "Gym", "Clubhouse"],
  status: "Ready to Move"
});

export default async function PropertyDetails({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const property = getProperty(id);

  return (
    <div className="pt-24 pb-20 bg-black">
      {/* Gallery Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 h-[600px] px-2 mb-12">
        <div className="h-full">
          <img src={property.images[0]} className="w-full h-full object-cover" alt={property.title} />
        </div>
        <div className="grid grid-rows-2 gap-2 h-full">
          <img src={property.images[1]} className="w-full h-full object-cover" alt="Interior" />
          <img src={property.images[2]} className="w-full h-full object-cover" alt="Interior" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-3 gap-12">
        {/* Left Column: Info */}
        <div className="lg:col-span-2 space-y-10">
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <span className="bg-gold/20 text-gold px-3 py-1 text-[10px] uppercase tracking-widest border border-gold/30">
                {property.status}
              </span>
              <span className="text-gray-500 text-xs uppercase tracking-widest flex items-center gap-1">
                <MapPin size={12} /> {property.location}
              </span>
            </div>
            <h1 className="text-4xl md:text-6xl font-serif font-bold">{property.title}</h1>
            <p className="text-3xl font-serif text-gold">{formatPrice(property.price)}</p>
          </div>

          <div className="grid grid-cols-3 gap-8 py-8 border-y border-white/5">
            <div className="text-center space-y-2">
              <Bed className="mx-auto text-gold" size={24} />
              <p className="text-xs uppercase tracking-widest text-gray-500">{property.beds} Bedrooms</p>
            </div>
            <div className="text-center space-y-2 border-x border-white/5">
              <Bath className="mx-auto text-gold" size={24} />
              <p className="text-xs uppercase tracking-widest text-gray-500">{property.baths} Bathrooms</p>
            </div>
            <div className="text-center space-y-2">
              <Square className="mx-auto text-gold" size={24} />
              <p className="text-xs uppercase tracking-widest text-gray-500">{property.sqft} Sqft Area</p>
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-2xl font-serif font-bold">The Description</h3>
            <p className="text-gray-400 leading-relaxed font-light">{property.description}</p>
          </div>

          <div className="space-y-6">
            <h3 className="text-2xl font-serif font-bold">Amenities</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {property.features.map(f => (
                <div key={f} className="flex items-center gap-2 text-sm text-gray-300">
                  <CheckCircle size={16} className="text-gold" />
                  {f}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Sidebar */}
        <div className="space-y-8">
          <div className="bg-luxury-charcoal border border-gold/20 p-8 space-y-6 sticky top-28">
            <h3 className="text-xl font-serif font-bold text-white">Schedule a Visit</h3>
            <form className="space-y-4">
              <input className="w-full bg-black border border-white/10 p-3 text-sm focus:border-gold outline-none" placeholder="Your Name" />
              <input className="w-full bg-black border border-white/10 p-3 text-sm focus:border-gold outline-none" placeholder="Your Phone" />
              <button className="btn-gold w-full flex items-center justify-center gap-2 py-4">
                <Calendar size={18} /> Book Visit
              </button>
            </form>
            <p className="text-[10px] text-center text-gray-500 uppercase tracking-widest font-bold">OR</p>
            <div className="flex gap-2">
               <a href="tel:7900780022" className="btn-outline-gold flex-grow text-center text-xs py-3">Call Now</a>
               <a href="https://wa.me/917900780022" className="btn-outline-gold flex-grow text-center text-xs py-3">WhatsApp</a>
            </div>
          </div>
          
          <EMICalculator />
        </div>
      </div>
    </div>
  );
}
